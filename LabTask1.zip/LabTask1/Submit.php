<!DOCTYPE html>
<html lang="en">
<head>
    <title>Submit</title>
</head>
<body>
   <h1>Your Registration Done</h1>
</body>
</html>